export default function AppointmentsPage() {
  return <div>Appointments Page - Under Construction</div>;
}
