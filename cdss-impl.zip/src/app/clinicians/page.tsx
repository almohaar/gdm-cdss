export default function CliniciansPage () {
    return <div>Clinicians Page - Under Construction</div>;
}
